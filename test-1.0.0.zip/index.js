var request=require('request');
function sendMessage(){
	var packet={
		time: new Date().getTime(),
		data: Math.random()*100
	};
	request.post("http://imsofa.rocks:8080/LabUtils/ws/app-messages", {
		json:{
			applicationId: "test",
			content: JSON.stringify(packet),
			timestamp: packet.time
		}
	}, function(){
		console.log("message sent: "+packet.data);
		setTimeout(sendMessage, 3000);
	});
}
sendMessage();
