var fs=require('fs');
var request=require('request');

var images=["1.png", "2.jpg", "3.jpg", "test_picture.png"];

fs.readFile(images[3], function(err, data){
    var base64=data.toString("base64");
    console.log(base64.substr(0,10));
    request.post("http://imsofa.rocks:8080/LabUtils/face/landmarks", {
        form:{
            "image": base64,
            "key": "imsofarocks",
            "timestamp": ""+new Date().getTime()
        }
    }, function(err, response, body){
        console.log(err);
        console.log(body);
    });
});