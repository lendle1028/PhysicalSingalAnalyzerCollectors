var NodeWebcam = require("node-webcam");
var request = require('request');

//Default options
var opts = {
    width: 640,
    height: 480,
    quality: 100,
    //Delay to take shot
    delay: 0,
    //Save shots in memory
    saveShots: true,
    // [jpeg, png] support varies
    // Webcam.OutputTypes
    output: "png",
    //Which camera to use
    //Use Webcam.list() for results
    //false for default device
    device: false,
    // [location, buffer, base64]
    // Webcam.CallbackReturnTypes
    callbackReturn: "base64",
    //Logging
    verbose: true,
    skip: 2
};

var applicationId = process.argv[2];
var interval = parseInt(process.argv[3]);
var usesample = (process.argv.length >= 5 && process.argv[4] == "true");
//Creates webcam instance
var Webcam = NodeWebcam.create(opts);
setTimeout(capture, interval);

function capture() {
    if (usesample) {
        request.post("http://imsofa.rocks:8080/LabUtils/ws/app-messages", {
            json: {
                "applicationId": applicationId,
                content: JSON.stringify({
                    mlel: 0.5,
                    mrer: 0.6,
                    nlml: 0.5,
                    nrmr: 0.8,
                    nlel: 0.5,
                    nrer: 0.3
                })
            }
        }, function () {
            setTimeout(capture, interval);
        });
    } else {
        Webcam.capture("test_picture", function (err, data) {
            var index = data.indexOf(",");
            data = data.substr(index + 1);
            request.post("http://imsofa.rocks:8080/LabUtils/face/landmarks", {
                form: {
                    "image": data,
                    "key": "imsofarocks",
                    "timestamp": "" + new Date().getTime()
                }
            }, function (err, response, body) {
                if (body && ("" + body).length > 5) {
                    request.post("http://imsofa.rocks:8080/LabUtils/ws/app-messages", {
                        json: {
                            "applicationId": applicationId,
                            content: JSON.stringify(body)
                        }
                    }, function () {
                        setTimeout(capture, interval);
                    });
                } else {
                    setTimeout(capture, interval);
                }
            });
        });
    }
}