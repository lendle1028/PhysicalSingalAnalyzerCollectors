const request = require('request');
const fs = require('fs');
const argv = require('yargs')
    .usage('Usage: $0 --user [username] --password [password] --email [email]')
    .alias('u', 'user')
    .alias('p', 'password')
    .alias('e', 'email')
    .demandOption(['u', 'p'])
    .argv;

if (!argv.e) {
    console.log('get email from account');
    request("https://api.github.com/users/lendle1028", {
        headers: {
            "User-Agent": "chrome",
            "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
        }
    }, function (error, response, body) {
        let user = JSON.parse(body);
        setTimeout(function () {
            upload(user);
        }, 500);
    });
}else{
    upload({
        'email': argv.e
    });
}

function createPackFile(){
    console.log("creating pack for "+(__dirname));
    if(fs.existsSync("package.json")){
        let json=fs.readFileSync("package.json");
        let packageJson=JSON.parse(json);
        const packToZip=require('pack-to-zip');
        let zipFileName=packageJson.name.replace("@", "").replace("/", "-")+"-"+packageJson.version+".zip";
        console.log(packToZip());
        console.log(zipFileName);
    }else{
        console.log("must have a package.json file");
        return null;
    }
}

function upload(user) {
    createPackFile();
    return;
    request("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/test.txt", {
        headers: {
            "User-Agent": "chrome"
        }
    },
        function (error, response, body) {
            body = JSON.parse(body);
            if (body.message != "Not Found") {
                request.put("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/test.txt", {
                    body: JSON.stringify({
                        sha: body.sha,
                        content: fs.readFileSync("test.js").toString("base64"),
                        message: "commit",
                        "committer": {
                            "name": argv.u,
                            "email": user.email
                        },
                    }),
                    headers: {
                        "User-Agent": "chrome",
                        "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
                    }
                },
                    function (error, response, body) {
                    }
                );
            } else {
                request.put("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/test.txt", {
                    body: JSON.stringify({
                        content: fs.readFileSync("test.js").toString("base64"),
                        message: "commit",
                        "committer": {
                            "name": argv.u,
                            "email": user.email
                        },
                    }),
                    headers: {
                        "User-Agent": "chrome",
                        "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
                    }
                },
                    function (error, response, body) {
                        //console.log(body);
                    }
                );
            }
        }
    );
}