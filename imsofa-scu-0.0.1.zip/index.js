const request = require('request');
const fs = require('fs');
const argv = require('yargs')
    .usage('Usage: $0 --user [username] --password [password] --email [email]')
    .alias('u', 'user')
    .alias('p', 'password')
    .alias('e', 'email')
    .demandOption(['u', 'p'])
    .argv;

if (!argv.e) {
    console.log('get email from account');
    request("https://api.github.com/users/lendle1028", {
        headers: {
            "User-Agent": "chrome",
            "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
        }
    }, function (error, response, body) {
        let user = JSON.parse(body);
        setTimeout(function () {
            upload(user);
        }, 500);
    });
}else{
    upload({
        'email': argv.e
    });
}

function createPackFile(){
    console.log("creating pack for "+(__dirname));
    if(fs.existsSync("package.json")){
        let json=fs.readFileSync("package.json");
        let packageJson=JSON.parse(json);
        const packToZip=require('pack-to-zip');
        let zipFileName=packageJson.name.replace("@", "").replace("/", "-")+"-"+packageJson.version+".zip";
        packToZip();
        console.log(zipFileName+" has been created");
        return zipFileName;
    }else{
        console.log("must have a package.json file");
        return null;
    }
}

function upload(user) {
    let zipFile=createPackFile();
    if(zipFile==null){
        return;
    }
    request("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/"+zipFile, {
        headers: {
            "User-Agent": "chrome"
        }
    },
        function (error, response, body) {
            body = JSON.parse(body);
            if (body.message != "Not Found") {
                request.put("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/"+zipFile, {
                    body: JSON.stringify({
                        sha: body.sha,
                        content: fs.readFileSync(zipFile).toString("base64"),
                        message: "commit",
                        "committer": {
                            "name": argv.u,
                            "email": user.email
                        },
                    }),
                    headers: {
                        "User-Agent": "chrome",
                        "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
                    }
                },
                    function (error, response, body) {
                        if(!error){
                            console.log("uploaded");
                        }else{
                            console.log(error);
                        }
                    }
                );
            } else {
                request.put("https://api.github.com/repos/lendle1028/PhysicalSingalAnalyzerCollectors/contents/"+zipFile, {
                    body: JSON.stringify({
                        content: fs.readFileSync(zipFile).toString("base64"),
                        message: "commit",
                        "committer": {
                            "name": argv.u,
                            "email": user.email
                        },
                    }),
                    headers: {
                        "User-Agent": "chrome",
                        "Authorization": "Basic " + Buffer.from(argv.u + ":" + argv.p).toString("base64")
                    }
                },
                    function (error, response, body) {
                        if(!error){
                            console.log("uploaded");
                        }else{
                            console.log(error);
                        }
                    }
                );
            }
        }
    );
}